var classhttpsserver_1_1HTTPHeader =
[
    [ "HTTPHeader", "classhttpsserver_1_1HTTPHeader.html#a983d37d85545e541948aedb6adafcd3d", null ],
    [ "~HTTPHeader", "classhttpsserver_1_1HTTPHeader.html#a17ff6b0d691718d372b3b19c4ab9a173", null ],
    [ "print", "classhttpsserver_1_1HTTPHeader.html#a9b03ce08467a5cddef58522e0119c9d6", null ],
    [ "_name", "classhttpsserver_1_1HTTPHeader.html#afe5713a1aa1d5d5bc0c78db5bfba8599", null ],
    [ "_value", "classhttpsserver_1_1HTTPHeader.html#a7c4e3d75d36ea413bc5ca2c96a86f0a8", null ]
];